import { Component, OnInit } from '@angular/core';
import { ApiService } from '../services/api.service';

@Component({
  selector: 'app-userhome',
  templateUrl: './userhome.component.html',
  styleUrls: ['./userhome.component.css']
})
export class UserhomeComponent implements OnInit {
  gamelist!:any;

  constructor(private api:ApiService){}
  ngOnInit(){
    this.api.getgames().subscribe(x=>{
      this.gamelist=x}); 
  }

  Buy(id:any){
    
  }
}
