import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
role!:string;
token:any;
  constructor(private hc:HttpClient) { }

  login(formdata:any){
    return this.hc.post('https://localhost:7081/api/Auth/login',formdata)
  }

  register(formdata:any){
    return this.hc.post('https://localhost:7081/api/Auth/register',formdata)
  }

  savetoken(tkn:any){
    console.log(tkn.token.value)
    console.log(tkn.role)
    this.role=tkn.role;
    this.token=tkn.token.value;
    localStorage.setItem('role',this.role)
    localStorage.setItem('token',this.token)
  }

  getrole(){
    return localStorage.getItem('role');
  }

  gettoken(){
  return localStorage.getItem('token');
  }

  logout(){
    localStorage.clear();
  }
}
