import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private hc:HttpClient) { }

  add(formdata:any){
    return this.hc.post('https://localhost:7081/api/Game',formdata)
  }

  getgames(){
    return this.hc.get('https://localhost:7081/api/Game')
  }

  deletegame(id:number){
    return this.hc.delete('https://localhost:7081/api/Game/'+id)
  }

  editproduct(formdata:any){
    return this.hc.put<any>('https://localhost:7081/api/Game/Edit',formdata);
  }
}
